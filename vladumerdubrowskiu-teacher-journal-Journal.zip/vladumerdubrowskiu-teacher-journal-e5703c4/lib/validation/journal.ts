import { z } from "zod";
import {
  CELL_VALUES,
  HOMEWORK_MAX_FILES,
  HOMEWORK_MAX_FILE_BYTES,
  HOMEWORK_MAX_TEXT_LENGTH,
  WORK_TYPE_KEYS,
} from "@/lib/journal";

const dateSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Некорректная дата");

export const journalLessonSchema = z.object({
  classId: z.string().min(1, "Класс обязателен").max(200),
  date: dateSchema,
  workType: z.enum(WORK_TYPE_KEYS).optional(),
});

export type JournalLessonInput = z.infer<typeof journalLessonSchema>;

export const journalCellSchema = z.object({
  classId: z.string().min(1, "Класс обязателен").max(200),
  date: dateSchema,
  studentId: z.string().min(1, "Ученик обязателен").max(200),
  value: z.enum(CELL_VALUES).or(z.literal("")),
});

export type JournalCellInput = z.infer<typeof journalCellSchema>;

export const homeworkSaveSchema = z.object({
  classId: z.string().min(1, "Класс обязателен").max(200),
  date: dateSchema,
  homework: z.string().max(HOMEWORK_MAX_TEXT_LENGTH),
});

export type HomeworkSaveInput = z.infer<typeof homeworkSaveSchema>;

export const homeworkFileSchema = z.object({
  id: z.string().min(1).max(200),
  name: z.string().min(1, "Имя файла обязательно").max(255),
  type: z.string().max(200).default("application/octet-stream"),
  size: z.number().int().nonnegative().max(HOMEWORK_MAX_FILE_BYTES),
  data: z.string().min(1, "Файл пуст"),
});

export type HomeworkFileInput = z.infer<typeof homeworkFileSchema>;

export const homeworkFilesAppendSchema = z.object({
  classId: z.string().min(1, "Класс обязателен").max(200),
  date: dateSchema,
  files: z.array(homeworkFileSchema).min(1).max(HOMEWORK_MAX_FILES),
});

export type HomeworkFilesAppendInput = z.infer<
  typeof homeworkFilesAppendSchema
>;

export const homeworkFileDeleteSchema = z.object({
  classId: z.string().min(1, "Класс обязателен").max(200),
  date: dateSchema,
  fileId: z.string().min(1).max(200),
});

export type HomeworkFileDeleteInput = z.infer<typeof homeworkFileDeleteSchema>;
