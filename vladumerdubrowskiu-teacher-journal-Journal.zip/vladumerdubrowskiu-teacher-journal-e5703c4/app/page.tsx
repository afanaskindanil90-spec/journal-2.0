import { isDatabaseAvailable } from "@/lib/db";
import { getAllClasses, seedClassesIfEmpty } from "@/lib/models";
import { mockClasses } from "@/lib/mock-data";
import { JournalPage } from "@/components/journal-page";

export default async function HomePage() {
  let initialClasses = mockClasses;
  try {
    if (await isDatabaseAvailable()) {
      await seedClassesIfEmpty();
      initialClasses = await getAllClasses();
    }
  } catch {
    initialClasses = mockClasses;
  }

  return <JournalPage initialClasses={initialClasses} />;
}
