import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { mockJournal } from "@/lib/mock-data";
import {
  ensureJournalSeeded,
  getJournalLessons,
  upsertJournalLesson,
} from "@/lib/models";
import { journalLessonSchema } from "@/lib/validation/journal";

export async function GET(request: NextRequest) {
  const classId = request.nextUrl.searchParams.get("classId");
  if (!classId) {
    return NextResponse.json({ error: "classId обязателен" }, { status: 400 });
  }

  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(
      mockJournal.filter((item) => item.classId === classId)
    );
  }

  try {
    await ensureJournalSeeded(classId);
    return NextResponse.json(await getJournalLessons(classId));
  } catch (error) {
    console.error("Failed to fetch journal:", error);
    return NextResponse.json(
      { error: "Не удалось загрузить журнал" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    body = null;
  }

  const parsed = journalLessonSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "Некорректные данные",
        details: parsed.error.flatten(),
      },
      { status: 400 }
    );
  }

  try {
    const lesson = await upsertJournalLesson(parsed.data);
    return NextResponse.json(lesson);
  } catch (error) {
    console.error("Failed to save journal lesson:", error);
    return NextResponse.json(
      { error: "Не удалось сохранить урок" },
      { status: 500 }
    );
  }
}
