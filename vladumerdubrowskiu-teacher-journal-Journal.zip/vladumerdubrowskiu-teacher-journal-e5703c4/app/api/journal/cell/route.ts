import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { setJournalCell } from "@/lib/models";
import { journalCellSchema } from "@/lib/validation/journal";

export async function PATCH(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    body = null;
  }

  const parsed = journalCellSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "Некорректные данные",
        details: parsed.error.flatten(),
      },
      { status: 400 }
    );
  }

  try {
    const lesson = await setJournalCell(parsed.data);
    return NextResponse.json(lesson);
  } catch (error) {
    console.error("Failed to save journal cell:", error);
    return NextResponse.json(
      { error: "Не удалось сохранить оценку" },
      { status: 500 }
    );
  }
}
