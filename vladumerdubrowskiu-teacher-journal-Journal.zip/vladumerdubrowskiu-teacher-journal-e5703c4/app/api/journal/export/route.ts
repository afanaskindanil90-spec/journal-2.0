import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  buildContentDisposition,
  buildCsv,
  buildXlsx,
  type ExportFormat,
} from "@/lib/export";
import { mockClasses, mockJournal } from "@/lib/mock-data";
import {
  ensureJournalSeeded,
  getClassById,
  getJournalLessons,
  type SchoolClass,
} from "@/lib/models";

function isValidFormat(value: string | null): value is ExportFormat {
  return value === "csv" || value === "xlsx";
}

export async function GET(request: NextRequest) {
  const classId = request.nextUrl.searchParams.get("classId");
  const format = request.nextUrl.searchParams.get("format");

  if (!classId) {
    return NextResponse.json({ error: "classId обязателен" }, { status: 400 });
  }
  if (!isValidFormat(format)) {
    return NextResponse.json(
      { error: "Некорректный формат экспорта" },
      { status: 400 }
    );
  }

  let schoolClass: SchoolClass | null;
  let lessons;

  if (await isDatabaseAvailable()) {
    try {
      schoolClass = await getClassById(classId);
      if (!schoolClass) {
        return NextResponse.json({ error: "Класс не найден" }, { status: 404 });
      }
      await ensureJournalSeeded(classId);
      lessons = await getJournalLessons(classId);
    } catch (error) {
      console.error("Failed to export journal:", error);
      return NextResponse.json(
        { error: "Не удалось сформировать файл экспорта" },
        { status: 500 }
      );
    }
  } else {
    schoolClass = mockClasses.find((item) => item.id === classId) ?? null;
    if (!schoolClass) {
      return NextResponse.json({ error: "Класс не найден" }, { status: 404 });
    }
    lessons = mockJournal.filter((item) => item.classId === classId);
  }

  const exportData = {
    className: schoolClass.name,
    students: schoolClass.students,
    lessons,
  };

  const fileName = `journal-${schoolClass.name}`;

  if (format === "csv") {
    return new Response(buildCsv(exportData), {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": buildContentDisposition(`${fileName}.csv`),
      },
    });
  }

  const buffer = buildXlsx(exportData);
  return new Response(new Uint8Array(buffer), {
    headers: {
      "Content-Type":
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition": buildContentDisposition(`${fileName}.xlsx`),
      "Content-Length": String(buffer.byteLength),
    },
  });
}

export const dynamic = "force-dynamic";
export const preferredRegion = undefined;
