import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { saveHomeworkText } from "@/lib/models";
import { homeworkSaveSchema } from "@/lib/validation/journal";

export async function PATCH(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    body = null;
  }

  const parsed = homeworkSaveSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "Некорректные данные",
        details: parsed.error.flatten(),
      },
      { status: 400 }
    );
  }

  try {
    const lesson = await saveHomeworkText(parsed.data);
    return NextResponse.json(lesson);
  } catch (error) {
    console.error("Failed to save homework:", error);
    return NextResponse.json(
      { error: "Не удалось сохранить домашнее задание" },
      { status: 500 }
    );
  }
}
