import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import {
  HOMEWORK_MAX_FILE_BYTES,
  HOMEWORK_MAX_TOTAL_BYTES,
} from "@/lib/journal";
import {
  appendHomeworkFiles,
  getJournalLesson,
  removeHomeworkFile,
} from "@/lib/models";
import {
  homeworkFileDeleteSchema,
  homeworkFilesAppendSchema,
} from "@/lib/validation/journal";

export async function POST(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    body = null;
  }

  const parsed = homeworkFilesAppendSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "Некорректные данные",
        details: parsed.error.flatten(),
      },
      { status: 400 }
    );
  }

  try {
    const files = parsed.data.files.map((file) => ({
      id: file.id,
      name: file.name,
      type: file.type,
      size: Buffer.byteLength(file.data, "base64"),
      data: file.data,
    }));

    if (files.some((file) => file.size > HOMEWORK_MAX_FILE_BYTES)) {
      return NextResponse.json(
        { error: "Файл слишком большой — максимум 200 КБ" },
        { status: 400 }
      );
    }

    const batchBytes = files.reduce((sum, file) => sum + file.size, 0);
    const lesson = await getJournalLesson(
      parsed.data.classId,
      parsed.data.date
    );
    const existingBytes = (lesson?.homeworkFiles ?? []).reduce(
      (sum, file) => sum + file.size,
      0
    );

    if (existingBytes + batchBytes > HOMEWORK_MAX_TOTAL_BYTES) {
      return NextResponse.json(
        { error: "Суммарный размер файлов к заданию превышает лимит 250 КБ" },
        { status: 400 }
      );
    }

    const updated = await appendHomeworkFiles({
      classId: parsed.data.classId,
      date: parsed.data.date,
      files,
    });
    if (!updated) {
      return NextResponse.json({ error: "Урок не найден" }, { status: 404 });
    }
    return NextResponse.json(updated);
  } catch (error) {
    console.error("Failed to append homework files:", error);
    return NextResponse.json(
      { error: "Не удалось прикрепить файлы" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const parsed = homeworkFileDeleteSchema.safeParse({
    classId: request.nextUrl.searchParams.get("classId"),
    date: request.nextUrl.searchParams.get("date"),
    fileId: request.nextUrl.searchParams.get("fileId"),
  });
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Некорректные параметры" },
      { status: 400 }
    );
  }

  try {
    const updated = await removeHomeworkFile(parsed.data);
    if (!updated) {
      return NextResponse.json({ error: "Урок не найден" }, { status: 404 });
    }
    return NextResponse.json(updated);
  } catch (error) {
    console.error("Failed to remove homework file:", error);
    return NextResponse.json(
      { error: "Не удалось удалить файл" },
      { status: 500 }
    );
  }
}
