import { NextRequest, NextResponse } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { addStudent } from "@/lib/models";
import { studentSchema } from "@/lib/validation/classes";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ classId: string }> }
) {
  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  const { classId } = await params;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    body = null;
  }

  const parsed = studentSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "Некорректные данные",
        details: parsed.error.flatten(),
      },
      { status: 400 }
    );
  }

  try {
    const schoolClass = await addStudent(classId, parsed.data);
    if (!schoolClass) {
      return NextResponse.json({ error: "Класс не найден" }, { status: 404 });
    }
    return NextResponse.json(schoolClass, { status: 201 });
  } catch (error) {
    console.error("Failed to add student:", error);
    return NextResponse.json(
      { error: "Не удалось добавить ученика" },
      { status: 500 }
    );
  }
}
