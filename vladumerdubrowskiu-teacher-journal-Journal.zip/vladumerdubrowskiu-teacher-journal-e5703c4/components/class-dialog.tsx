"use client";

import { useEffect, useState, type FormEvent } from "react";
import { AlertCircle, GraduationCap, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { classNameSchema, type ClassInput } from "@/lib/validation/classes";

interface ClassDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (input: ClassInput) => Promise<void>;
}

export function ClassDialog({
  open,
  onOpenChange,
  onSubmit,
}: ClassDialogProps) {
  const [name, setName] = useState("");
  const [isMyClass, setIsMyClass] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (open) {
      setName("");
      setIsMyClass(false);
      setError(null);
    }
  }, [open]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);

    const parsed = classNameSchema.safeParse({ name, isMyClass });
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? "Проверьте название класса");
      return;
    }

    setSubmitting(true);
    try {
      await onSubmit(parsed.data);
      onOpenChange(false);
    } catch (submitError) {
      setError(
        submitError instanceof Error
          ? submitError.message
          : "Не удалось добавить класс"
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Новый класс</DialogTitle>
          <DialogDescription>
            Добавьте класс в журнал. Учеников можно внести позже.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {error && (
            <div
              role="alert"
              className="flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2.5 text-sm text-destructive"
            >
              <AlertCircle className="mt-0.5 size-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="flex flex-col gap-1.5">
            <Label htmlFor="class-name">Название класса</Label>
            <Input
              id="class-name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="Например, 6А"
              disabled={submitting}
              autoFocus
            />
          </div>

          <label className="flex cursor-pointer items-center gap-2 text-sm select-none">
            <Checkbox
              checked={isMyClass}
              onCheckedChange={setIsMyClass}
              disabled={submitting}
            />
            <span>Мой класс (я — классный руководитель)</span>
          </label>

          <DialogFooter>
            <DialogClose render={<Button variant="outline" />}>
              Отмена
            </DialogClose>
            <Button type="submit" disabled={submitting}>
              {submitting ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <GraduationCap className="size-4" />
              )}
              Добавить
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
