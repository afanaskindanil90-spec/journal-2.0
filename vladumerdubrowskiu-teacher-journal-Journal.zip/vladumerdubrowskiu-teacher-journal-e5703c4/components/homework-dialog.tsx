"use client";

import { useEffect, useRef, useState, type ChangeEvent } from "react";
import {
  AlertCircle,
  Download,
  File,
  FileImage,
  FileText,
  Loader2,
  Paperclip,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import {
  HOMEWORK_ACCEPT,
  HOMEWORK_MAX_FILES,
  HOMEWORK_MAX_FILE_BYTES,
  HOMEWORK_MAX_TEXT_LENGTH,
  HOMEWORK_MAX_TOTAL_BYTES,
  WORK_TYPE_LABELS,
  formatDateLong,
  type WorkTypeKey,
} from "@/lib/journal";
import type { HomeworkFile, JournalLesson } from "@/lib/models";

interface HomeworkDialogProps {
  open: boolean;
  classId: string;
  date: string;
  lesson: JournalLesson | null;
  onOpenChange: (open: boolean) => void;
  onSaved: (lesson: JournalLesson) => void;
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} Б`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} КБ`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} МБ`;
}

function fileIconFor(type: string, name: string) {
  if (type.startsWith("image/")) return FileImage;
  if (type === "application/pdf" || /\.pdf$/i.test(name)) return FileText;
  return File;
}

function readFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = typeof reader.result === "string" ? reader.result : "";
      resolve(result.split(",")[1] ?? "");
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function downloadHomeworkFile(file: HomeworkFile) {
  const bytes = Uint8Array.from(atob(file.data), (char) => char.charCodeAt(0));
  const blob = new Blob([bytes], {
    type: file.type || "application/octet-stream",
  });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = file.name;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}

export function HomeworkDialog({
  open,
  classId,
  date,
  lesson,
  onOpenChange,
  onSaved,
}: HomeworkDialogProps) {
  const [homework, setHomework] = useState("");
  const [files, setFiles] = useState<HomeworkFile[]>([]);
  const [savingText, setSavingText] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [removingId, setRemovingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const prevOpenRef = useRef(false);

  useEffect(() => {
    if (open && !prevOpenRef.current) {
      setHomework(lesson?.homework ?? "");
      setFiles(lesson?.homeworkFiles ?? []);
      setError(null);
      setSavingText(false);
      setUploading(false);
      setRemovingId(null);
    }
    prevOpenRef.current = open;
  }, [open, date, lesson]);

  async function handleSaveText() {
    setError(null);
    const text = homework.trim();
    setSavingText(true);
    try {
      const response = await fetch("/api/journal/homework", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ classId, date, homework: text }),
      });
      if (!response.ok) {
        const data = (await response.json().catch(() => null)) as {
          error?: string;
        } | null;
        throw new Error(data?.error ?? "Не удалось сохранить домашнее задание");
      }
      const updated = (await response.json()) as JournalLesson;
      onSaved(updated);
      setHomework(updated.homework ?? "");
      toast.success(
        text ? "Домашнее задание сохранено" : "Домашнее задание очищено"
      );
    } catch (saveError) {
      const message =
        saveError instanceof Error
          ? saveError.message
          : "Не удалось сохранить домашнее задание";
      setError(message);
      toast.error(message);
    } finally {
      setSavingText(false);
    }
  }

  async function handleFileChange(event: ChangeEvent<HTMLInputElement>) {
    const selected = Array.from(event.target.files ?? []);
    event.target.value = "";
    if (selected.length === 0) return;

    if (files.length + selected.length > HOMEWORK_MAX_FILES) {
      toast.error(
        `К заданию можно прикрепить не больше ${HOMEWORK_MAX_FILES} файлов`
      );
      return;
    }

    setError(null);
    setUploading(true);
    try {
      const newFiles: HomeworkFile[] = [];
      let totalBytes = files.reduce((sum, file) => sum + file.size, 0);

      for (const file of selected) {
        if (totalBytes + file.size > HOMEWORK_MAX_TOTAL_BYTES) {
          toast.error("Суммарный размер файлов превышает лимит 250 КБ");
          break;
        }
        if (file.size > HOMEWORK_MAX_FILE_BYTES) {
          toast.error(`Файл «${file.name}» слишком большой — максимум 200 КБ`);
          continue;
        }
        const data = await readFileAsBase64(file);
        newFiles.push({
          id: crypto.randomUUID(),
          name: file.name,
          type: file.type || "application/octet-stream",
          size: file.size,
          data,
        });
        totalBytes += file.size;
      }

      if (newFiles.length === 0) return;

      const response = await fetch("/api/journal/homework/files", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ classId, date, files: newFiles }),
      });
      if (!response.ok) {
        const data = (await response.json().catch(() => null)) as {
          error?: string;
        } | null;
        throw new Error(data?.error ?? "Не удалось прикрепить файлы");
      }
      const updated = (await response.json()) as JournalLesson;
      onSaved(updated);
      setFiles(updated.homeworkFiles ?? []);
      toast.success(`Прикреплено файлов: ${newFiles.length}`);
    } catch (uploadError) {
      const message =
        uploadError instanceof Error
          ? uploadError.message
          : "Не удалось прикрепить файлы";
      setError(message);
      toast.error(message);
    } finally {
      setUploading(false);
    }
  }

  async function handleRemoveFile(file: HomeworkFile) {
    setRemovingId(file.id);
    try {
      const params = new URLSearchParams({ classId, date, fileId: file.id });
      const response = await fetch(
        `/api/journal/homework/files?${params.toString()}`,
        { method: "DELETE" }
      );
      if (!response.ok) {
        const data = (await response.json().catch(() => null)) as {
          error?: string;
        } | null;
        throw new Error(data?.error ?? "Не удалось удалить файл");
      }
      const updated = (await response.json()) as JournalLesson;
      onSaved(updated);
      setFiles(updated.homeworkFiles ?? []);
      toast.success("Файл удалён");
    } catch (removeError) {
      const message =
        removeError instanceof Error
          ? removeError.message
          : "Не удалось удалить файл";
      toast.error(message);
    } finally {
      setRemovingId(null);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Домашнее задание</DialogTitle>
          <DialogDescription>
            Урок за {formatDateLong(date)}
            {lesson?.workType &&
              (() => {
                const workTypeKey = lesson.workType as WorkTypeKey;
                return WORK_TYPE_LABELS[workTypeKey]
                  ? ` · ${WORK_TYPE_LABELS[workTypeKey]}`
                  : "";
              })()}
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-4">
          {error && (
            <div
              role="alert"
              className="flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2.5 text-sm text-destructive"
            >
              <AlertCircle className="mt-0.5 size-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="flex flex-col gap-1.5">
            <Label htmlFor="homework-text">Текст задания</Label>
            <Textarea
              id="homework-text"
              value={homework}
              onChange={(event) => setHomework(event.target.value)}
              maxLength={HOMEWORK_MAX_TEXT_LENGTH}
              placeholder="Что задано на этот урок?"
              rows={4}
            />
            <div className="flex items-center justify-between gap-2">
              <Button
                type="button"
                size="sm"
                onClick={handleSaveText}
                disabled={savingText || uploading}
              >
                {savingText ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <FileText className="size-4" />
                )}
                Сохранить текст
              </Button>
              <span className="text-xs text-muted-foreground">
                {homework.length}/{HOMEWORK_MAX_TEXT_LENGTH}
              </span>
            </div>
          </div>

          <Separator />

          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between gap-2">
              <Label>Файлы ({files.length})</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                disabled={uploading || files.length >= HOMEWORK_MAX_FILES}
                onClick={() => fileInputRef.current?.click()}
              >
                {uploading ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <Paperclip className="size-4" />
                )}
                Прикрепить файлы
              </Button>
              <Input
                ref={fileInputRef}
                type="file"
                multiple
                accept={HOMEWORK_ACCEPT}
                className="hidden"
                onChange={handleFileChange}
                disabled={uploading}
              />
            </div>

            {files.length === 0 ? (
              <p className="rounded-lg border border-dashed bg-muted/40 px-3 py-4 text-center text-sm text-muted-foreground">
                Пока нет прикреплённых файлов. Можно добавить фото, PDF или
                документы.
              </p>
            ) : (
              <ul className="flex flex-col gap-1.5">
                {files.map((file) => {
                  const Icon = fileIconFor(file.type, file.name);
                  return (
                    <li
                      key={file.id}
                      className="flex items-center gap-2 rounded-lg border bg-card px-2.5 py-2"
                    >
                      <span className="flex size-8 shrink-0 items-center justify-center rounded-md bg-muted">
                        <Icon className="size-4 text-muted-foreground" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">
                          {file.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {formatFileSize(file.size)}
                        </p>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon-sm"
                        aria-label={`Скачать ${file.name}`}
                        onClick={() => downloadHomeworkFile(file)}
                      >
                        <Download />
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon-sm"
                        className="text-destructive hover:text-destructive"
                        aria-label={`Удалить ${file.name}`}
                        disabled={removingId === file.id}
                        onClick={() => handleRemoveFile(file)}
                      >
                        {removingId === file.id ? (
                          <Loader2 className="size-4 animate-spin" />
                        ) : (
                          <Trash2 />
                        )}
                      </Button>
                    </li>
                  );
                })}
              </ul>
            )}

            <p className="text-xs text-muted-foreground">
              До {HOMEWORK_MAX_FILES} файлов, до 200 КБ каждый и до 250 КБ
              суммарно (фото, PDF, документы).
            </p>
          </div>
        </div>

        <DialogFooter>
          <DialogClose render={<Button variant="outline" />}>
            Закрыть
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
