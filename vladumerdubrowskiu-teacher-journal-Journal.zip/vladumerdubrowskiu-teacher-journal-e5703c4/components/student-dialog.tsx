"use client";

import { useEffect, useState, type FormEvent } from "react";
import { AlertCircle, Loader2, UserPlus, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { Student } from "@/lib/models";
import { studentSchema, type StudentInput } from "@/lib/validation/classes";

interface StudentDialogProps {
  open: boolean;
  mode: "add" | "edit";
  student?: Student;
  classNameLabel?: string;
  onOpenChange: (open: boolean) => void;
  onSubmit: (input: StudentInput) => Promise<void>;
}

export function StudentDialog({
  open,
  mode,
  student,
  classNameLabel,
  onOpenChange,
  onSubmit,
}: StudentDialogProps) {
  const [lastName, setLastName] = useState("");
  const [firstName, setFirstName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const isEdit = mode === "edit";

  useEffect(() => {
    if (open) {
      setLastName(student?.lastName ?? "");
      setFirstName(student?.firstName ?? "");
      setError(null);
    }
  }, [open, student]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);

    const parsed = studentSchema.safeParse({ lastName, firstName });
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? "Проверьте данные ученика");
      return;
    }

    setSubmitting(true);
    try {
      await onSubmit(parsed.data);
      onOpenChange(false);
    } catch (submitError) {
      setError(
        submitError instanceof Error
          ? submitError.message
          : "Не удалось сохранить ученика"
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            {isEdit ? "Изменить ученика" : "Добавить ученика"}
          </DialogTitle>
          <DialogDescription>
            {isEdit
              ? `Обновите данные ученика в классе ${classNameLabel ?? ""}.`
              : `Новый ученик будет добавлен в класс ${classNameLabel ?? ""}.`}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {error && (
            <div
              role="alert"
              className="flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2.5 text-sm text-destructive"
            >
              <AlertCircle className="mt-0.5 size-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="flex flex-col gap-1.5">
            <Label htmlFor="student-last-name">Фамилия</Label>
            <Input
              id="student-last-name"
              value={lastName}
              onChange={(event) => setLastName(event.target.value)}
              placeholder="Иванов"
              disabled={submitting}
              autoFocus
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <Label htmlFor="student-first-name">Имя</Label>
            <Input
              id="student-first-name"
              value={firstName}
              onChange={(event) => setFirstName(event.target.value)}
              placeholder="Алексей"
              disabled={submitting}
            />
          </div>

          <DialogFooter>
            <DialogClose render={<Button variant="outline" />}>
              Отмена
            </DialogClose>
            <Button type="submit" disabled={submitting}>
              {submitting ? (
                <Loader2 className="size-4 animate-spin" />
              ) : isEdit ? (
                <Users className="size-4" />
              ) : (
                <UserPlus className="size-4" />
              )}
              {isEdit ? "Сохранить" : "Добавить"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
