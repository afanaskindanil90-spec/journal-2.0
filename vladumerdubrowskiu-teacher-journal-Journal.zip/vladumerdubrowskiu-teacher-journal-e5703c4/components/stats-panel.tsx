"use client";

import { BarChart3 } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ATTENDANCE_LABELS, ATTENDANCE_MARKS } from "@/lib/journal";
import type { JournalLesson, Student } from "@/lib/models";
import {
  computeClassStats,
  computeStudentStats,
  formatAverage,
} from "@/lib/stats";

interface StatsPanelProps {
  students: Student[];
  lessons: JournalLesson[];
}

export function StatsPanel({ students, lessons }: StatsPanelProps) {
  const classStats = computeClassStats(lessons);

  return (
    <Card className="mt-4">
      <CardHeader>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="size-4 text-primary" />
              Статистика успеваемости и посещаемости
            </CardTitle>
            <CardDescription className="mt-1">
              Средние баллы и пропуски считаются автоматически по всем урокам
              журнала.
            </CardDescription>
          </div>
          <div className="rounded-xl bg-primary/10 px-4 py-2 text-center">
            <p className="text-[11px] font-medium tracking-wide text-primary uppercase">
              Средний балл класса
            </p>
            <p className="text-2xl leading-tight font-semibold tabular-nums">
              {formatAverage(classStats.classAverageGrade)}
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full min-w-max border-separate border-spacing-0 text-sm">
            <thead>
              <tr>
                <th
                  scope="col"
                  className="sticky left-0 z-20 min-w-52 border-b border-r bg-muted px-3 py-2 text-left text-xs font-medium tracking-wide text-muted-foreground"
                >
                  Ученик
                </th>
                <th
                  scope="col"
                  className="min-w-24 border-b bg-muted px-2 py-2 text-center text-xs font-medium tracking-wide text-muted-foreground"
                >
                  Средний балл
                </th>
                {ATTENDANCE_MARKS.map((mark) => (
                  <th
                    key={mark}
                    scope="col"
                    title={ATTENDANCE_LABELS[mark]}
                    className="min-w-10 border-b bg-muted px-2 py-2 text-center text-xs font-semibold text-foreground"
                  >
                    {mark}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="[&>tr:last-child>td]:border-b-0">
              {students.map((student) => {
                const stats = computeStudentStats(student, lessons);
                return (
                  <tr key={student.id}>
                    <td className="sticky left-0 z-10 border-r bg-card px-3 py-2">
                      <span className="font-medium whitespace-nowrap">
                        {student.lastName} {student.firstName}
                      </span>
                    </td>
                    <td className="px-2 py-2 text-center font-semibold tabular-nums text-primary">
                      {formatAverage(stats.averageGrade)}
                    </td>
                    {ATTENDANCE_MARKS.map((mark) => (
                      <td
                        key={mark}
                        className="px-2 py-2 text-center tabular-nums text-muted-foreground"
                      >
                        {stats.absences[mark] > 0 ? stats.absences[mark] : "—"}
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr>
                <td className="sticky left-0 z-10 border-r bg-muted/60 px-3 py-2 text-sm font-medium whitespace-nowrap">
                  По классу
                </td>
                <td className="bg-muted/60 px-2 py-2 text-center text-sm font-semibold tabular-nums text-primary">
                  {formatAverage(classStats.classAverageGrade)}
                </td>
                {ATTENDANCE_MARKS.map((mark) => (
                  <td
                    key={mark}
                    className="bg-muted/60 px-2 py-2 text-center text-sm font-medium tabular-nums"
                  >
                    {classStats.absences[mark] > 0
                      ? classStats.absences[mark]
                      : "—"}
                  </td>
                ))}
              </tr>
            </tfoot>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
