"use client";

import { useCallback, useEffect, useState } from "react";
import {
  BookOpen,
  GraduationCap,
  Plus,
  Star,
  Trash2,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogMedia,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { ClassDialog } from "@/components/class-dialog";
import { ExportMenu } from "@/components/export-menu";
import { JournalGrid } from "@/components/journal-grid";
import { StudentDialog } from "@/components/student-dialog";
import type { SchoolClass, Student } from "@/lib/models";
import type { ClassInput, StudentInput } from "@/lib/validation/classes";

interface DeleteTarget {
  type: "class" | "student";
  id: string;
  label: string;
  classId?: string;
}

interface JournalPageProps {
  initialClasses: SchoolClass[];
}

export function JournalPage({ initialClasses }: JournalPageProps) {
  const [classes, setClasses] = useState<SchoolClass[]>(initialClasses);
  const [activeClassId, setActiveClassId] = useState<string | null>(
    initialClasses[0]?.id ?? null
  );
  const [loading, setLoading] = useState(initialClasses.length === 0);
  const [classDialogOpen, setClassDialogOpen] = useState(false);
  const [studentDialog, setStudentDialog] = useState<{
    open: boolean;
    mode: "add" | "edit";
    student?: Student;
  }>({ open: false, mode: "add" });
  const [deleteTarget, setDeleteTarget] = useState<DeleteTarget | null>(null);

  const activeClass = classes.find((item) => item.id === activeClassId) ?? null;

  const loadClasses = useCallback(async () => {
    const res = await fetch("/api/classes", { cache: "no-store" });
    if (!res.ok) throw new Error("Не удалось загрузить классы");
    return (await res.json()) as SchoolClass[];
  }, []);

  const refresh = useCallback(async () => {
    try {
      const data = await loadClasses();
      setClasses(data);
      setLoading(false);
      setActiveClassId((current) =>
        current && data.some((item) => item.id === current)
          ? current
          : (data[0]?.id ?? null)
      );
      return data;
    } catch {
      setLoading(false);
      return null;
    }
  }, [loadClasses]);

  useEffect(() => {
    let cancelled = false;
    loadClasses()
      .then((data) => {
        if (cancelled) return;
        setClasses(data);
        setActiveClassId((current) =>
          current && data.some((item) => item.id === current)
            ? current
            : (data[0]?.id ?? null)
        );
      })
      .catch(() => {
        // Сервер уже передал начальные данные; тихо оставляем их.
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [loadClasses]);

  async function handleAddClass(input: ClassInput) {
    const res = await fetch("/api/classes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    });
    if (!res.ok) {
      const data = (await res.json().catch(() => null)) as {
        error?: string;
      } | null;
      throw new Error(data?.error ?? "Не удалось добавить класс");
    }
    const created = (await res.json()) as SchoolClass;
    await refresh();
    setActiveClassId(created.id);
    toast.success("Класс добавлен");
  }

  async function handleDeleteClass() {
    if (!deleteTarget || deleteTarget.type !== "class") return;
    const id = deleteTarget.id;
    setDeleteTarget(null);
    const res = await fetch(`/api/classes?id=${encodeURIComponent(id)}`, {
      method: "DELETE",
    });
    if (!res.ok) {
      toast.error("Не удалось удалить класс");
      await refresh();
      return;
    }
    await refresh();
    toast.success("Класс удалён");
  }

  async function handleAddStudent(input: StudentInput) {
    if (!activeClass) return;
    const res = await fetch(
      `/api/classes/${encodeURIComponent(activeClass.id)}/students`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(input),
      }
    );
    if (!res.ok) {
      const data = (await res.json().catch(() => null)) as {
        error?: string;
      } | null;
      throw new Error(data?.error ?? "Не удалось добавить ученика");
    }
    await refresh();
    toast.success("Ученик добавлен");
  }

  async function handleUpdateStudent(studentId: string, input: StudentInput) {
    if (!activeClass) return;
    const res = await fetch(
      `/api/classes/${encodeURIComponent(activeClass.id)}/students/${encodeURIComponent(studentId)}`,
      {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(input),
      }
    );
    if (!res.ok) {
      const data = (await res.json().catch(() => null)) as {
        error?: string;
      } | null;
      throw new Error(data?.error ?? "Не удалось изменить ученика");
    }
    await refresh();
    toast.success("Ученик изменён");
  }

  async function handleDeleteStudent() {
    if (
      !deleteTarget ||
      deleteTarget.type !== "student" ||
      !deleteTarget.classId
    ) {
      return;
    }
    const { id, classId } = deleteTarget;
    setDeleteTarget(null);
    const res = await fetch(
      `/api/classes/${encodeURIComponent(classId)}/students/${encodeURIComponent(id)}`,
      { method: "DELETE" }
    );
    if (!res.ok) {
      toast.error("Не удалось удалить ученика");
      await refresh();
      return;
    }
    await refresh();
    toast.success("Ученик удалён");
  }

  function renderEmptyState() {
    if (classes.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center gap-3 py-20 text-center">
          <div className="flex size-14 items-center justify-center rounded-full bg-muted">
            <GraduationCap className="size-6 text-muted-foreground" />
          </div>
          <p className="text-sm font-medium">Пока нет ни одного класса</p>
          <p className="max-w-sm text-sm text-muted-foreground">
            Добавьте первый класс, чтобы начать вести журнал.
          </p>
          <Button onClick={() => setClassDialogOpen(true)}>
            <Plus className="size-4" />
            Добавить класс
          </Button>
        </div>
      );
    }

    return (
      <div className="flex flex-col items-center justify-center gap-3 py-20 text-center">
        <div className="flex size-14 items-center justify-center rounded-full bg-muted">
          <Users className="size-6 text-muted-foreground" />
        </div>
        <p className="text-sm font-medium">В классе пока нет учеников</p>
        <p className="max-w-sm text-sm text-muted-foreground">
          Добавьте учеников, чтобы заполнить журнал класса {activeClass?.name}.
        </p>
        <Button onClick={() => setStudentDialog({ open: true, mode: "add" })}>
          <Plus className="size-4" />
          Добавить ученика
        </Button>
      </div>
    );
  }

  return (
    <div className="flex min-h-[calc(100vh-8rem)] animate-in fade-in slide-in-from-bottom-4 duration-500">
      <aside className="hidden w-64 shrink-0 flex-col border-r bg-sidebar p-4 md:flex">
        <div className="mb-2 flex items-center gap-2 px-2 text-xs font-medium tracking-wide text-muted-foreground uppercase">
          <Users className="size-3.5" />
          Классы
        </div>

        {loading ? (
          <div className="flex flex-col gap-1">
            <Skeleton className="h-9 w-full" />
            <Skeleton className="h-9 w-full" />
            <Skeleton className="h-9 w-full" />
            <Skeleton className="h-9 w-full" />
            <Skeleton className="h-9 w-full" />
            <Skeleton className="h-9 w-full" />
          </div>
        ) : (
          <div className="flex flex-col gap-1">
            {classes.map((cls) => {
              const active = cls.id === activeClassId;
              return (
                <div
                  key={cls.id}
                  className={cn(
                    "group flex items-center overflow-hidden rounded-lg transition-colors",
                    active
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-accent"
                  )}
                >
                  <button
                    type="button"
                    onClick={() => setActiveClassId(cls.id)}
                    aria-pressed={active}
                    className="flex min-w-0 flex-1 items-center justify-between gap-2 px-3 py-2 text-left text-sm"
                  >
                    <span className="flex min-w-0 items-center gap-2">
                      <span className="truncate font-medium">{cls.name}</span>
                      {cls.isMyClass && (
                        <span
                          className={cn(
                            "flex shrink-0 items-center gap-1 text-[11px]",
                            active
                              ? "text-primary-foreground/80"
                              : "text-primary"
                          )}
                        >
                          <Star className="size-3 fill-current" />
                          мой класс
                        </span>
                      )}
                    </span>
                    <span
                      className={cn(
                        "shrink-0 text-xs tabular-nums",
                        active
                          ? "text-primary-foreground/70"
                          : "text-muted-foreground"
                      )}
                    >
                      {cls.students.length}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setDeleteTarget({
                        type: "class",
                        id: cls.id,
                        label: cls.name,
                      })
                    }
                    aria-label={`Удалить класс ${cls.name}`}
                    className={cn(
                      "flex size-8 shrink-0 items-center justify-center rounded-l-none text-muted-foreground opacity-0 transition-all focus-visible:opacity-100 group-hover:opacity-100",
                      active
                        ? "text-primary-foreground/60 hover:text-primary-foreground"
                        : "hover:bg-destructive/10 hover:text-destructive"
                    )}
                  >
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        )}

        <Button
          variant="outline"
          size="sm"
          className="mt-3 w-full justify-start"
          onClick={() => setClassDialogOpen(true)}
        >
          <Plus className="size-4" />
          Добавить класс
        </Button>
      </aside>

      <main className="min-w-0 flex-1 p-4 md:p-6">
        <div className="mb-4 flex gap-2 overflow-x-auto pb-1 md:hidden">
          {classes.map((cls) => {
            const active = cls.id === activeClassId;
            return (
              <button
                key={cls.id}
                type="button"
                onClick={() => setActiveClassId(cls.id)}
                aria-pressed={active}
                className={cn(
                  "shrink-0 rounded-lg px-3 py-1.5 text-sm font-medium transition-colors",
                  active
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-accent"
                )}
              >
                {cls.name}
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => setClassDialogOpen(true)}
            aria-label="Добавить класс"
            className="flex shrink-0 items-center gap-1 rounded-lg bg-muted px-3 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent"
          >
            <Plus className="size-3.5" />
          </button>
        </div>

        <header className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded-xl bg-primary/10">
              <BookOpen className="size-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">
                Журнал успеваемости
              </p>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-semibold tracking-tight">
                  {activeClass?.name ?? "Классы"}
                </h1>
                {activeClass?.isMyClass && (
                  <Badge variant="secondary" className="gap-1">
                    <Star className="size-3 fill-current" />
                    мой класс
                  </Badge>
                )}
              </div>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="outline" className="gap-1.5 text-muted-foreground">
              <Users className="size-3.5" />
              {activeClass ? `${activeClass.students.length} уч.` : "—"}
            </Badge>
            <Button
              size="sm"
              disabled={!activeClass}
              onClick={() => setStudentDialog({ open: true, mode: "add" })}
            >
              <Plus className="size-4" />
              Ученик
            </Button>
            <ExportMenu
              classId={activeClass?.id ?? null}
              className={activeClass?.name ?? null}
            />
          </div>
        </header>

        <div
          key={activeClass?.id ?? "empty"}
          className="animate-in fade-in slide-in-from-bottom-4 duration-300"
        >
          {!activeClass || activeClass.students.length === 0 ? (
            renderEmptyState()
          ) : (
            <JournalGrid
              classId={activeClass.id}
              students={activeClass.students}
              onEditStudent={(student) =>
                setStudentDialog({ open: true, mode: "edit", student })
              }
              onDeleteStudent={(student) =>
                setDeleteTarget({
                  type: "student",
                  id: student.id,
                  label: `${student.lastName} ${student.firstName}`,
                  classId: activeClass.id,
                })
              }
            />
          )}
        </div>
      </main>

      <ClassDialog
        open={classDialogOpen}
        onOpenChange={setClassDialogOpen}
        onSubmit={handleAddClass}
      />

      <StudentDialog
        open={studentDialog.open}
        mode={studentDialog.mode}
        student={studentDialog.student}
        classNameLabel={activeClass?.name}
        onOpenChange={(open) =>
          setStudentDialog((state) => ({ ...state, open }))
        }
        onSubmit={async (input) => {
          if (studentDialog.mode === "edit" && studentDialog.student) {
            await handleUpdateStudent(studentDialog.student.id, input);
          } else {
            await handleAddStudent(input);
          }
        }}
      />

      <AlertDialog
        open={deleteTarget !== null}
        onOpenChange={(open) => {
          if (!open) setDeleteTarget(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogMedia>
              <Trash2 />
            </AlertDialogMedia>
            <AlertDialogTitle>
              {deleteTarget && deleteTarget.type === "class"
                ? "Удалить класс?"
                : "Удалить ученика?"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget &&
                (deleteTarget.type === "class"
                  ? `Класс «${deleteTarget.label}» будет удалён вместе со всеми его учениками. Это действие нельзя отменить.`
                  : `Ученик «${deleteTarget.label}» будет удалён из класса. Это действие нельзя отменить.`)}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction
              variant="destructive"
              onClick={
                deleteTarget?.type === "class"
                  ? handleDeleteClass
                  : handleDeleteStudent
              }
            >
              Удалить
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
