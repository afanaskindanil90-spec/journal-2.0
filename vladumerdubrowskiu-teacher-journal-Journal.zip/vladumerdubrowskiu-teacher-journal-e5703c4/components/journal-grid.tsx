"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  AlertCircle,
  CalendarPlus,
  Loader2,
  NotebookPen,
  Pencil,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverDescription,
  PopoverHeader,
  PopoverTitle,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import {
  ATTENDANCE_LABELS,
  ATTENDANCE_MARKS,
  GRADES,
  WORK_TYPE_KEYS,
  WORK_TYPE_LABELS,
  formatDateHeader,
  formatDateLong,
  isAttendanceMark,
  isGrade,
  type WorkTypeKey,
} from "@/lib/journal";
import type { JournalLesson, Student } from "@/lib/models";
import { journalCellSchema } from "@/lib/validation/journal";
import { HomeworkDialog } from "@/components/homework-dialog";
import { StatsPanel } from "@/components/stats-panel";

interface JournalGridProps {
  classId: string;
  students: Student[];
  onEditStudent: (student: Student) => void;
  onDeleteStudent: (student: Student) => void;
}

interface CellEditorProps {
  date: string;
  student: Student;
  value: string | undefined;
  workType: WorkTypeKey | undefined;
  onChange: (value: string) => void;
}

function CellEditor({
  date,
  student,
  value,
  workType,
  onChange,
}: CellEditorProps) {
  const [open, setOpen] = useState(false);

  function pick(nextValue: string) {
    onChange(nextValue);
    setOpen(false);
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger
        aria-label={`Оценка для ${student.lastName} ${student.firstName} за ${formatDateLong(date)}`}
        className={cn(
          "flex h-8 w-full items-center justify-center rounded-md text-sm font-semibold tabular-nums transition-colors outline-none hover:bg-accent focus-visible:ring-3 focus-visible:ring-ring/50",
          value && isGrade(value) && "text-primary",
          value && isAttendanceMark(value) && "bg-muted text-foreground"
        )}
      >
        {value ?? <span className="text-muted-foreground/30">–</span>}
      </PopoverTrigger>
      <PopoverContent className="w-80">
        <PopoverHeader>
          <PopoverTitle>
            {student.lastName} {student.firstName}
          </PopoverTitle>
          <PopoverDescription>
            {formatDateLong(date)}
            {workType ? ` · ${WORK_TYPE_LABELS[workType]}` : ""}
          </PopoverDescription>
        </PopoverHeader>

        <div className="flex flex-col gap-3 pt-1">
          <div className="flex flex-col gap-1.5">
            <span className="text-xs font-medium text-muted-foreground">
              Оценка
            </span>
            <div className="grid grid-cols-4 gap-1.5">
              {GRADES.map((grade) => (
                <button
                  key={grade}
                  type="button"
                  disabled={!workType}
                  title={
                    workType
                      ? "Выставить оценку"
                      : "Сначала выберите тип работы"
                  }
                  onClick={() => pick(grade)}
                  className={cn(
                    "flex h-9 items-center justify-center rounded-lg border text-sm font-semibold tabular-nums transition-colors outline-none focus-visible:ring-3 focus-visible:ring-ring/50",
                    value === grade
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-input text-foreground hover:bg-accent",
                    !workType &&
                      "cursor-not-allowed opacity-40 hover:bg-transparent"
                  )}
                >
                  {grade}
                </button>
              ))}
            </div>
            {!workType && (
              <p className="text-xs leading-snug text-muted-foreground">
                Сначала выберите тип работы в шапке столбца, чтобы ставить
                оценки.
              </p>
            )}
          </div>

          <Separator />

          <div className="flex flex-col gap-1.5">
            <span className="text-xs font-medium text-muted-foreground">
              Посещаемость
            </span>
            <div className="grid grid-cols-6 gap-1.5">
              {ATTENDANCE_MARKS.map((mark) => (
                <button
                  key={mark}
                  type="button"
                  title={ATTENDANCE_LABELS[mark]}
                  onClick={() => pick(mark)}
                  className={cn(
                    "flex h-9 items-center justify-center rounded-lg border text-sm font-semibold transition-colors outline-none focus-visible:ring-3 focus-visible:ring-ring/50",
                    value === mark
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-input text-foreground hover:bg-accent"
                  )}
                >
                  {mark}
                </button>
              ))}
            </div>
          </div>

          {value && (
            <>
              <Separator />
              <Button
                variant="ghost"
                size="sm"
                className="w-full"
                onClick={() => pick("")}
              >
                Очистить ячейку
              </Button>
            </>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}

interface AddLessonDialogProps {
  open: boolean;
  existingDates: Set<string>;
  onOpenChange: (open: boolean) => void;
  onSubmit: (date: string) => Promise<void>;
}

function AddLessonDialog({
  open,
  existingDates,
  onOpenChange,
  onSubmit,
}: AddLessonDialogProps) {
  const [date, setDate] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (open) {
      setDate("");
      setError(null);
    }
  }, [open]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    if (!date) {
      setError("Выберите дату урока");
      return;
    }
    if (existingDates.has(date)) {
      setError("Урок на эту дату уже есть в журнале");
      return;
    }
    setSubmitting(true);
    try {
      await onSubmit(date);
      onOpenChange(false);
    } catch (submitError) {
      setError(
        submitError instanceof Error
          ? submitError.message
          : "Не удалось добавить урок"
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Добавить урок</DialogTitle>
          <DialogDescription>
            Выберите дату урока — она появится новым столбцом в журнале.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {error && (
            <div
              role="alert"
              className="flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2.5 text-sm text-destructive"
            >
              <AlertCircle className="mt-0.5 size-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="flex flex-col gap-1.5">
            <Label htmlFor="lesson-date">Дата урока</Label>
            <Input
              id="lesson-date"
              type="date"
              value={date}
              onChange={(event) => setDate(event.target.value)}
              disabled={submitting}
              autoFocus
            />
          </div>

          <DialogFooter>
            <DialogClose render={<Button variant="outline" />}>
              Отмена
            </DialogClose>
            <Button type="submit" disabled={submitting}>
              {submitting ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <CalendarPlus className="size-4" />
              )}
              Добавить
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function JournalGrid({
  classId,
  students,
  onEditStudent,
  onDeleteStudent,
}: JournalGridProps) {
  const [lessons, setLessons] = useState<JournalLesson[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [homeworkDialogDate, setHomeworkDialogDate] = useState<string | null>(
    null
  );

  const lessonsByDate = useMemo(() => {
    const map = new Map<string, JournalLesson>();
    for (const lesson of lessons) map.set(lesson.date, lesson);
    return map;
  }, [lessons]);

  const dates = useMemo(
    () =>
      lessons.map((lesson) => lesson.date).sort((a, b) => a.localeCompare(b)),
    [lessons]
  );

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setLoadError(false);
    fetch(`/api/journal?classId=${encodeURIComponent(classId)}`, {
      cache: "no-store",
    })
      .then(async (response) => {
        if (!response.ok) throw new Error("Не удалось загрузить журнал");
        return (await response.json()) as JournalLesson[];
      })
      .then((data) => {
        if (!cancelled) setLessons(data);
      })
      .catch(() => {
        if (!cancelled) setLoadError(true);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [classId]);

  function upsertLessonLocal(lesson: JournalLesson) {
    setLessons((prev) => {
      const index = prev.findIndex((item) => item.date === lesson.date);
      if (index === -1) {
        return [...prev, lesson].sort((a, b) => a.date.localeCompare(b.date));
      }
      const next = [...prev];
      next[index] = lesson;
      return next;
    });
  }

  function removeLessonLocal(date: string) {
    setLessons((prev) => prev.filter((item) => item.date !== date));
  }

  async function handleWorkTypeChange(date: string, workType: string) {
    const previous = lessonsByDate.get(date);
    upsertLessonLocal({
      classId,
      date,
      workType,
      entries: previous?.entries ?? {},
    });

    try {
      const response = await fetch("/api/journal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ classId, date, workType }),
      });
      if (!response.ok) throw new Error("save failed");
      upsertLessonLocal((await response.json()) as JournalLesson);
      toast.success("Тип работы сохранён");
    } catch {
      if (previous) {
        upsertLessonLocal(previous);
      } else {
        removeLessonLocal(date);
      }
      toast.error("Не удалось сохранить тип работы");
    }
  }

  async function handleCellChange(
    date: string,
    studentId: string,
    value: string
  ) {
    const parsed = journalCellSchema.safeParse({
      classId,
      date,
      studentId,
      value,
    });
    if (!parsed.success) {
      toast.error("Некорректное значение");
      return;
    }

    const lesson = lessonsByDate.get(date);
    const previousEntries = lesson?.entries ?? {};
    const nextEntries = { ...previousEntries };
    if (value === "") {
      delete nextEntries[studentId];
    } else {
      nextEntries[studentId] = value;
    }
    upsertLessonLocal({
      classId,
      date,
      workType: lesson?.workType,
      entries: nextEntries,
    });

    try {
      const response = await fetch("/api/journal/cell", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed.data),
      });
      if (!response.ok) throw new Error("save failed");
      upsertLessonLocal((await response.json()) as JournalLesson);
    } catch {
      upsertLessonLocal({
        classId,
        date,
        workType: lesson?.workType,
        entries: previousEntries,
      });
      toast.error("Не удалось сохранить изменение");
    }
  }

  async function handleAddLesson(date: string) {
    const response = await fetch("/api/journal", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ classId, date }),
    });
    if (!response.ok) {
      const data = (await response.json().catch(() => null)) as {
        error?: string;
      } | null;
      throw new Error(data?.error ?? "Не удалось добавить урок");
    }
    upsertLessonLocal((await response.json()) as JournalLesson);
    toast.success("Урок добавлен");
  }

  if (loading) {
    return (
      <div className="overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10">
        <div className="overflow-x-auto p-4">
          <div className="flex flex-col gap-3">
            <Skeleton className="h-8 w-full" />
            {Array.from({ length: 6 }).map((_, index) => (
              <Skeleton key={index} className="h-9 w-full" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 rounded-xl bg-card py-16 text-center ring-1 ring-foreground/10">
        <div className="flex size-14 items-center justify-center rounded-full bg-muted">
          <AlertCircle className="size-6 text-muted-foreground" />
        </div>
        <p className="text-sm font-medium">Не удалось загрузить журнал</p>
        <p className="max-w-sm text-sm text-muted-foreground">
          Проверьте соединение и попробуйте ещё раз.
        </p>
        <Button
          variant="outline"
          onClick={() => {
            setLoading(true);
            setLoadError(false);
            window.location.reload();
          }}
        >
          Обновить
        </Button>
      </div>
    );
  }

  if (dates.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 rounded-xl bg-card py-16 text-center ring-1 ring-foreground/10">
        <div className="flex size-14 items-center justify-center rounded-full bg-muted">
          <CalendarPlus className="size-6 text-muted-foreground" />
        </div>
        <p className="text-sm font-medium">Пока нет ни одного урока</p>
        <p className="max-w-sm text-sm text-muted-foreground">
          Добавьте первый урок, чтобы начать вести журнал.
        </p>
        <Button onClick={() => setAddDialogOpen(true)}>
          <CalendarPlus className="size-4" />
          Добавить урок
        </Button>
      </div>
    );
  }

  return (
    <>
      <div className="overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b bg-muted/40 px-4 py-2">
          <p className="text-xs text-muted-foreground">
            Нажмите на ячейку, чтобы выставить оценку или отметку посещаемости.
          </p>
          <Button
            size="sm"
            variant="outline"
            onClick={() => setAddDialogOpen(true)}
          >
            <CalendarPlus className="size-4" />
            Добавить урок
          </Button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-max border-separate border-spacing-0 text-sm">
            <thead>
              <tr>
                <th
                  scope="col"
                  className="sticky left-0 z-20 min-w-52 border-b border-r bg-muted px-3 py-2 text-left text-xs font-medium tracking-wide text-muted-foreground"
                >
                  Ученик
                </th>
                {dates.map((date) => {
                  const lesson = lessonsByDate.get(date);
                  const workType = lesson?.workType as WorkTypeKey | undefined;
                  const hasHomework = Boolean(
                    lesson?.homework?.trim() ||
                    (lesson?.homeworkFiles?.length ?? 0) > 0
                  );
                  const fileCount = lesson?.homeworkFiles?.length ?? 0;
                  return (
                    <th
                      key={date}
                      scope="col"
                      className="min-w-36 border-b bg-muted px-2 py-2 text-center align-top"
                    >
                      <div className="mb-1.5 text-xs font-semibold text-foreground">
                        {formatDateHeader(date)}
                      </div>
                      <Select
                        value={workType ?? null}
                        items={WORK_TYPE_LABELS}
                        onValueChange={(value) => {
                          if (typeof value === "string") {
                            handleWorkTypeChange(date, value);
                          }
                        }}
                      >
                        <SelectTrigger
                          size="sm"
                          className="w-full justify-center text-xs"
                          aria-label={`Тип работы за ${formatDateHeader(date)}`}
                        >
                          <SelectValue placeholder="Тип работы" />
                        </SelectTrigger>
                        <SelectContent
                          align="center"
                          alignItemWithTrigger={false}
                        >
                          <SelectGroup>
                            {WORK_TYPE_KEYS.map((key) => (
                              <SelectItem key={key} value={key}>
                                {WORK_TYPE_LABELS[key]}
                              </SelectItem>
                            ))}
                          </SelectGroup>
                        </SelectContent>
                      </Select>
                      <Button
                        variant={hasHomework ? "outline" : "ghost"}
                        size="xs"
                        className={cn(
                          "mt-1.5 w-full justify-start gap-1",
                          hasHomework &&
                            "border-primary/30 text-primary hover:bg-primary/5"
                        )}
                        onClick={() => setHomeworkDialogDate(date)}
                        aria-label={`Домашнее задание на ${formatDateHeader(date)}`}
                      >
                        <NotebookPen className="size-3.5" />
                        {hasHomework ? "Домашнее задание" : "Добавить ДЗ"}
                        {fileCount > 0 && (
                          <span className="ml-auto rounded-full bg-primary/10 px-1.5 text-[11px] font-medium tabular-nums">
                            {fileCount}
                          </span>
                        )}
                      </Button>
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody className="[&>tr:last-child>td]:border-b-0">
              {students.map((student) => (
                <tr key={student.id} className="group">
                  <td className="sticky left-0 z-10 border-r bg-card px-3 py-1.5">
                    <div className="flex min-w-0 items-center justify-between gap-2">
                      <span className="truncate font-medium whitespace-nowrap">
                        {student.lastName} {student.firstName}
                      </span>
                      <div className="flex shrink-0 gap-0.5 opacity-0 transition-opacity focus-within:opacity-100 group-hover:opacity-100">
                        <Button
                          variant="ghost"
                          size="icon-sm"
                          aria-label={`Изменить ${student.lastName} ${student.firstName}`}
                          onClick={() => onEditStudent(student)}
                        >
                          <Pencil />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon-sm"
                          className="text-destructive hover:text-destructive"
                          aria-label={`Удалить ${student.lastName} ${student.firstName}`}
                          onClick={() => onDeleteStudent(student)}
                        >
                          <Trash2 />
                        </Button>
                      </div>
                    </div>
                  </td>
                  {dates.map((date) => {
                    const lesson = lessonsByDate.get(date);
                    const value = lesson?.entries[student.id];
                    const workType = lesson?.workType as
                      | WorkTypeKey
                      | undefined;
                    return (
                      <td
                        key={date}
                        className="border-b border-border/60 px-1 py-1.5 text-center"
                      >
                        <CellEditor
                          date={date}
                          student={student}
                          value={value}
                          workType={workType}
                          onChange={(nextValue) =>
                            handleCellChange(date, student.id, nextValue)
                          }
                        />
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <AddLessonDialog
          open={addDialogOpen}
          existingDates={new Set(dates)}
          onOpenChange={setAddDialogOpen}
          onSubmit={handleAddLesson}
        />

        <HomeworkDialog
          open={homeworkDialogDate !== null}
          classId={classId}
          date={homeworkDialogDate ?? ""}
          lesson={
            homeworkDialogDate
              ? (lessonsByDate.get(homeworkDialogDate) ?? null)
              : null
          }
          onOpenChange={(open) => {
            if (!open) setHomeworkDialogDate(null);
          }}
          onSaved={upsertLessonLocal}
        />
      </div>

      <StatsPanel students={students} lessons={lessons} />
    </>
  );
}
