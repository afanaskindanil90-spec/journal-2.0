"use client";

import { useState } from "react";
import { Download, FileSpreadsheet, FileText, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface ExportMenuProps {
  classId: string | null;
  className: string | null;
}

type ExportFormat = "csv" | "xlsx";

function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

export function ExportMenu({ classId, className }: ExportMenuProps) {
  const [exporting, setExporting] = useState<ExportFormat | null>(null);

  async function handleExport(format: ExportFormat) {
    if (!classId) return;
    setExporting(format);
    try {
      const response = await fetch(
        `/api/journal/export?classId=${encodeURIComponent(classId)}&format=${format}`,
        { cache: "no-store" }
      );
      if (!response.ok) throw new Error("export failed");
      const blob = await response.blob();
      const extension = format === "csv" ? "csv" : "xlsx";
      downloadBlob(blob, `journal-${className ?? "class"}.${extension}`);
      toast.success("Файл скачан");
    } catch {
      toast.error("Не удалось выгрузить журнал");
    } finally {
      setExporting(null);
    }
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        render={
          <Button
            variant="outline"
            size="sm"
            disabled={!classId || exporting !== null}
            aria-label="Экспортировать журнал текущего класса"
          />
        }
      >
        {exporting ? (
          <Loader2 className="size-4 animate-spin" />
        ) : (
          <Download className="size-4" />
        )}
        Экспорт
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem
          onClick={() => handleExport("csv")}
          disabled={!classId}
        >
          <FileText className="size-4" />
          Скачать CSV
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => handleExport("xlsx")}
          disabled={!classId}
        >
          <FileSpreadsheet className="size-4" />
          Скачать Excel
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
